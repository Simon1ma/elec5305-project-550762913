ELEC5305 Final Project - Yixiang Ma - SID 550762913
Revised 14 November 2026

This single ZIP includes the report, 181-second demonstration video, code link,
complete working source, public example, frozen models/features and result tables.

MATLAB: fully extract ZIP, set Current Folder to Code, run START_PROJECT.
Run START_PROJECT('check') for public-data numerical self-checks.
Requires Signal Processing Toolbox; tested on Windows 11 / MATLAB R2026a Update 5.
The public example requires no Python or further download. All four Wiener
methods are rerun; the DFNet3 quick-demo option plays explicitly saved output.

Public-corpus full evaluation downloads are documented in Code/code/final/README.md.
The project website and online report/video links are in GitHub_Code_Link.txt.
No second ZIP is required. AI assistance is acknowledged in the report.
