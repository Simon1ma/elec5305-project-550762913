# ELEC5305 final project submission

Research report: output/pdf/Final_Project_Yixiang_Ma.pdf (10 pages).
Code-and-audio demonstration: submissions/Final_Project_Demo.mp4 (94 seconds).
Runnable implementation: code/final/README.md; shared causal helpers are in code/latency/.
Primary exact results: results/final_external/README.md.
Secondary engineering comparison: results/final/README.md.
Attribution, protocol and training-overlap audit: docs/.

Original speech/noise archives, reference executable and pretrained weights are not redistributed. The documented scripts retrieve and verify them locally. The report explains the data, methods, results and limitations. Manifest.sha256.json checks every included file.
