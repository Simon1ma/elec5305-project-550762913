# ELEC5305 Project - Yixiang Ma (550762913)


## Download and test in MATLAB

**Final revision: 14 November 2026.** The report, video, code and project website are synchronised for resubmission.

Download [the repository ZIP](https://github.com/Simon1ma/elec5305-project-550762913/archive/refs/heads/main.zip), fully extract it, and set MATLAB Current Folder to the repository root. Run:

```matlab
START_PROJECT                    % Rerun original Wiener methods; plots and audio
START_PROJECT('check')           % Causality/reconstruction/output self-checks
START_PROJECT('classification')  % Bundled centroid model on public speech
```

Requires MATLAB with **Signal Processing Toolbox**; tested on Windows 11 / MATLAB R2026a Update 5. These commands need **no Python, personal recordings or further downloads**. A complete original public evaluation case (including calibration prefix) and exact saved outputs are bundled under `data/demo_public/`, with [source attributions](data/demo_public/ATTRIBUTION.md). Wiener10/20/40/80 are actually rerun and checked; the DeepFilterNet3 entry is labelled **saved reference** playback.

[Detailed MATLAB setup](START_HERE_MATLAB.txt) | [Update and provenance record](docs/CODE_UPDATE_20261114.md)

For frozen multi-scale scene-model evaluation, install the two documented Python requirement files, run `python code/scene/configure_runtime.py`, then `python code/scene/evaluate_scene_holdout.py`. Frozen models and extracted test features are included; no refitting is performed. Live rich-feature inference additionally needs MATLAB Audio Toolbox. Personal raw recordings remain private; their complete feature/mixing rebuild requires the original local recordings. The personal bridge/exploratory source code and numerical results are included.


## Latency-Quality Trade-offs in Real-Time Causal Speech Enhancement

**Project site:** https://simon1ma.github.io/elec5305-project-550762913/

**GitHub source code:** https://github.com/Simon1ma/elec5305-project-550762913

**Final report revised:** 14 November 2026

The final experiment preserves the stateful causal Wiener implementation and
official DeepFilterNet3 reference developed after teacher feedback. It evaluates
10/20/40/80 ms Wiener windows on two separate 144-mixture cohorts. The primary
external cohort uses LibriSpeech test-clean speech and recorded washing-machine
and keyboard noise at 0/5/10 dB. A native-48-kHz VCTK-derived cohort is retained
as a secondary engineering comparison because the reference paper mentions
VCTK in training. Neither cohort is claimed to be fully verified independent
of upstream model training.

**Final deliverables:** [16-page research report with linked contents](output/pdf/Final_Project_Yixiang_Ma.pdf)
| [181-second code and audio demonstration](submissions/Final_Project_Demo.mp4)
| [Runnable final code and setup](code/final/README.md)
| [Primary external results](results/final_external/README.md)
| [Secondary engineering results](results/final/README.md)
| [Source attributions](docs/final_data_attribution.md).

On the external 0 dB keyboard mixtures, the noisy/Wiener40/DeepFilterNet3 mean
STOI scores are 0.7336/0.6953/0.8998. Wiener40 increases waveform SNR to
2.13 dB while reducing STOI. At matched 40 ms oldest-sample block-ready delay,
DeepFilterNet3 obtains 13.55 dB SNR and 0.8998 STOI. These are speaker means,
not a live device-latency test. Full 864-row metrics, speaker bootstrap intervals,
causality evidence, timing distributions, limits and source identifiers are
provided with the code. The demo app reruns the chosen processor and plays the
clean, noisy and processed signals at one common gain.

## Earlier causal development (28 October 2026)

Following teacher feedback, the research focus is the latency-quality trade-off of causal enhancement. Wiener filtering is the classical baseline, not a novel algorithm. The second revised milestone adds real keyboard noise, event-level inspection, and an official pretrained DeepFilterNet3 reference to the stateful MATLAB experiment.

[Current results and limitations](results/latency_milestone2/README.md) | [Run the experiment](code/latency/README.md) | [Brief progress description](docs/project_progress2_working_description.md) | [Earlier causal milestone](results/latency_milestone1/README.md)

Both methods receive the same 48 kHz mixtures: 4.5 seconds from one VoiceBank development utterance, either DEMAND washing-machine or ESC-50 keyboard noise at 0 dB SNR, a 300 ms noise-only prefix, and a 100 ms recorded-noise tail. Four Wiener windows (10/20/40/80 ms) are compared. At a comparable 40 ms oldest-sample block-ready delay:

| Noise | Method | Output SNR (dB) | SI-SDR (dB) | STOI |
| --- | --- | --- | --- | --- |
| Washing machine | Noisy | 0.00 | -0.02 | 0.9263 |
| Washing machine | Wiener, 40 ms window | 2.27 | 2.22 | 0.9239 |
| Washing machine | DeepFilterNet3, 20 ms window | 18.90 | 18.97 | 0.9641 |
| Keyboard | Noisy | 0.00 | -0.07 | 0.7280 |
| Keyboard | Wiener, 40 ms window | 2.02 | 1.68 | 0.7020 |
| Keyboard | DeepFilterNet3, 20 ms window | 12.93 | 12.78 | 0.9092 |

These are measured development examples, not a held-out benchmark. No training or fine-tuning was performed. Source inspection, delay probes, and future-input tests support the reference's streaming interpretation; the quoted delay is not measured microphone-to-speaker latency. Backend and output-precision differences are disclosed in the detailed results. The main next step is broader speaker/source-disjoint evaluation at several SNRs.

## Historical Offline Progress (9 October 2026)

This project compares a fixed FIR low-pass baseline with STFT-domain Wiener filtering. The initial Python proposal has evolved into a MATLAB implementation, extending the synthetic-signal work from Audio Processing Report 1. The previous proposal is retained as a historical planning document.

## Implemented and Verified

- A reproducible 3-second synthetic speech-like signal at 16 kHz.
- Controlled mixing with white Gaussian noise and 60/120 Hz hum at 5 dB input SNR.
- Order-96 FIR baseline, 1200 Hz cutoff, Hamming window, and offline forward-backward filtering.
- Decision-directed STFT-domain Wiener enhancement using an initial 0.3-second noise-only prefix.
- Signal reconstruction checks, shared-input comparison, plots, metrics, and audio examples.
- Reference-to-error SNR on unnormalised outputs, excluding the noise-only prefix.

| Method | Input SNR (dB) | Output SNR (dB) | Improvement (dB) |
| --- | --- | --- | --- |
| Unprocessed | 5.00 | 5.00 | 0.00 |
| FIR | 5.00 | 12.32 | 7.32 |
| Wiener | 5.00 | 17.04 | 12.04 |

These were measured results for one synthetic example as of 9 October. They did not establish performance on real speech or improved intelligibility. Later recorded-speech experiments are documented separately above.

[Detailed results and limitations](results/preliminary/README.md) | [Code and execution instructions](code/README.md) | [Brief progress submission](docs/project_progress_submission.md)

## Run in MATLAB

Requires MATLAB with Signal Processing Toolbox. From the repository root:

```matlab
addpath(fullfile(pwd, 'code'));
results = main_preliminary();
```

Run `check_preliminary()` for reconstruction, length, gain, prefix-selection, SNR-mixing, and repeatability checks. The tested MATLAB version is R2026a Update 5.

## Repository Contents

- `code/`: runnable MATLAB implementation, configuration, and checks.
- `results/preliminary/`: actual numerical outputs, English-labelled plots, audio examples, and unscaled signals in a MAT file.
- `docs/`: progress submission description.
- `index.md`: GitHub Pages project overview.

## Separate Coursework: Audio Processing Report 2

**Temporal Modulation Filtering and Wavelet Analysis of Recorded Speech**

This is an independent MATLAB Live Script report, not the Final Project final submission. It examines 4/8/16 Hz temporal modulation masks, reconstruction fidelity, and continuous wavelet analysis of one recorded speech utterance.

[Report folder](<Report2 YixiangMa/>) | [PDF](<Report2 YixiangMa/Report2 YixiangMa.pdf>) | [MATLAB Live Script](<Report2 YixiangMa/Report2 YixiangMa.mlx>) | [Submission ZIP](<submissions/Report2 YixiangMa.zip>) | [Verification](docs/audio_processing_report2_verification.md)

MATLAB R2026a Update 5 with Signal Processing Toolbox and Wavelet Toolbox was tested. Extract the ZIP, set MATLAB's Current Folder to `Report2 YixiangMa`, open the Live Script, and run all sections. The input audio, source attribution, licence, and custom helpers are included. Generated outputs are recreated locally rather than committed.

## Next Work

Expand beyond the current single development utterance. Separate development and evaluation speakers and noise source recordings before segmenting or mixing, freeze settings on development data, then evaluate at 0, 5, and 10 dB. Examine speech distortion, transient-noise failures, and per-block deadlines. Do not reuse this development utterance as untouched evaluation data.

Full source datasets will not be uploaded. Selected file IDs, channels, segment offsets, and seeds will be documented.
